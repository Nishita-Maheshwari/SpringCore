package in.sp.beans;

public class MyBean 
{
	String name="Deepak";
	
	public void show()
	{
		System.out.println("Hello "+name+"....!!");
	}
}