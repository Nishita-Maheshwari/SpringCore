package in.sp.beans;

public class HelloBean
{
	public void show()
	{
		System.out.println("hello....!!");
	}
}
